# snow_script

A macro language with low level macros like if statements, jumps, and memory control and high level futures like memory dump, type, type casting, push, and calc

### Running
`./ssc filename.ssc`

### Syntax
view syntax.txt for macros and uses
	
