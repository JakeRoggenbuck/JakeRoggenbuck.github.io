# hash-colorer
### View hashes as colors

## Use
Pipe something to `hashc`<br>
e.g. `sha256sum file | hashc`

## Install
Run `./install.sh` as root
