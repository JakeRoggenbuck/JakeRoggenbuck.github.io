# RUSHNOTE
Take quick notes from command line when in a rush.

### Install
* `git clone https://github.com/JakeRoggenbuck/RushNote.git`
* `cd RushNote`
* `sudo make && sudo make install`

### For more information
`man rushnote`

#### Security
notes have very open privileges (777)
all users can read, write and execute the save file
