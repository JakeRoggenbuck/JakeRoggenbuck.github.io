# impulse

# Install
Run `./impulse.build` with root permissions

# Use
Read the man page
