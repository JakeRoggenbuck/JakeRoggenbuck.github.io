![alt text](https://raw.githubusercontent.com/jakeroggenbuck/amethyst/master/amethyst.png)
<br>A simple package manager written in ruby

### Install
run 'sh impulse.build'

### Help
run `amethyst -h`
