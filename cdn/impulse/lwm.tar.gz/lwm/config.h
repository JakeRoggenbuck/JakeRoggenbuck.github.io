#ifndef CONFIG_H
#define CONFIG_H

#define MOD             Mod4Mask
#define MASTER_SIZE     0.6

// Colors
#define FOCUS           "rgb:52/152/219"
#define UNFOCUS         "rgb:88/88/88"

const char* dmenucmd[] = {"dmenu_run",NULL};
const char* termcmd[]  = {"alacritty",NULL};
const char* lockcmd[]  = {"slock",NULL};
const char* next[]     = {"ncmpcpp","next",NULL};
const char* prev[]     = {"ncmpcpp","prev",NULL};
const char* toggle[]   = {"ncmpcpp","toggle",NULL };
const char* voldown[]  = {"amixer","-D","pulse","Master","5\%-",NULL};
const char* volup[]    = {"amixer","-D","pulse","Master","5\%+",NULL};

#define DESKTOPCHANGE(K,N) \
    {  MOD,             K,                          change_desktop, {.i = N}}, \
    {  MOD|ShiftMask,   K,                          client_to_desktop, {.i = N}},

// Shortcuts
static struct key keys[] = {
    // MOD              KEY                         FUNCTION        ARGS
    {  MOD,             XK_h,                       decrease,       {NULL}},
    {  MOD,             XK_l,                       increase,       {NULL}},
    {  MOD,             XK_w,                       kill_client,    {NULL}},
    {  MOD,             XK_j,                       next_win,       {NULL}},
    {  MOD,             XK_Tab,                     next_win,       {NULL}},
    {  MOD,             XK_k,                       prev_win,       {NULL}},
    {  MOD|ShiftMask,   XK_j,                       move_up,        {NULL}},
    {  MOD|ShiftMask,   XK_k,                       move_down,      {NULL}},
    {  MOD|ShiftMask,   XK_Return,                  swap_master,    {NULL}},
    {  MOD,             XK_space,                   switch_mode,    {NULL}},
    {  MOD,             XK_c,                       spawn,          {.com = lockcmd}},
    {  0,               XF86XK_AudioNext,           spawn,          {.com = next}},
    {  0,               XF86XK_AudioPrev,           spawn,          {.com = prev}},
    {  0,               XF86XK_AudioPlay,           spawn,          {.com = toggle}},
    {  0,               XF86XK_AudioLowerVolume,    spawn,          {.com = voldown}},
    {  0,               XF86XK_AudioRaiseVolume,    spawn,          {.com = volup}},
    {  MOD,             XK_d,                       spawn,          {.com = dmenucmd}},
    {  MOD,             XK_Return,                  spawn,          {.com = termcmd}},
    {  MOD,             XK_Right,                   next_desktop,   {NULL}},
    {  MOD,             XK_Left,                    prev_desktop,   {NULL}},
       DESKTOPCHANGE(   XK_0,                                       0)
       DESKTOPCHANGE(   XK_1,                                       1)
       DESKTOPCHANGE(   XK_2,                                       2)
       DESKTOPCHANGE(   XK_3,                                       3)
       DESKTOPCHANGE(   XK_4,                                       4)
       DESKTOPCHANGE(   XK_5,                                       5)
       DESKTOPCHANGE(   XK_6,                                       6)
       DESKTOPCHANGE(   XK_7,                                       7)
       DESKTOPCHANGE(   XK_8,                                       8)
       DESKTOPCHANGE(   XK_9,                                       9)
    {  MOD|ShiftMask,   XK_e,                       quit,           {NULL}}
};

#endif

